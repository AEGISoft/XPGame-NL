XP Game Template.doc: the template --> the format of the cards
XP Game Cards.xls: the content of the stories 

-> open "XP Game Template.doc", choose "merge". 

XP Game Cards.doc en XP Game Cards.pdf --> the result
